/**
 * Pure TypeScript implementation of Shamir's Secret Sharing Scheme over Galois Field GF(256).
 * Splits a string/secret into N shares with a threshold K required for reconstruction.
 */

// Galois Field GF(256) tables with primitive polynomial 0x11d
const PRIMITIVE = 0x11d;
const EXP = new Uint8Array(512);
const LOG = new Uint8Array(256);

(function initGF() {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    EXP[i] = x;
    EXP[i + 255] = x;
    LOG[x] = i;
    x <<= 1;
    if (x & 0x100) {
      x ^= PRIMITIVE;
    }
  }
})();

function gfAdd(a: number, b: number): number {
  return a ^ b;
}

function gfMul(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return EXP[LOG[a] + LOG[b]];
}

function gfDiv(a: number, b: number): number {
  if (b === 0) throw new Error('Division by zero in GF(256)');
  if (a === 0) return 0;
  return EXP[LOG[a] - LOG[b] + 255];
}

/**
 * Evaluates a polynomial with coefficients `coeffs` at point `x`.
 * f(x) = coeffs[0] + coeffs[1]*x + coeffs[2]*x^2 + ...
 */
function evalPoly(coeffs: Uint8Array, x: number): number {
  let result = 0;
  for (let i = coeffs.length - 1; i >= 0; i--) {
    result = gfAdd(gfMul(result, x), coeffs[i]);
  }
  return result;
}

/**
 * Split a secret string or Uint8Array into N shares with threshold K.
 * Returns array of share strings in format "x-hexdata".
 */
export function splitSecret(secret: string, totalShares: number, threshold: number): string[] {
  if (threshold > totalShares) throw new Error('Threshold cannot exceed total shares');
  if (threshold < 2) throw new Error('Threshold must be at least 2');
  if (totalShares > 254) throw new Error('Maximum total shares supported is 254');

  const encoder = new TextEncoder();
  const secretBytes = encoder.encode(secret);
  const shares: Uint8Array[] = [];

  for (let i = 0; i < totalShares; i++) {
    shares.push(new Uint8Array(secretBytes.length));
  }

  // Process byte by byte
  for (let byteIdx = 0; byteIdx < secretBytes.length; byteIdx++) {
    const a0 = secretBytes[byteIdx];
    const coeffs = new Uint8Array(threshold);
    coeffs[0] = a0;

    // Generate random coefficients for higher order terms
    const randomBytes = new Uint8Array(threshold - 1);
    crypto.getRandomValues(randomBytes);
    for (let c = 1; c < threshold; c++) {
      coeffs[c] = randomBytes[c - 1];
    }

    // Evaluate for x = 1..N
    for (let x = 1; x <= totalShares; x++) {
      shares[x - 1][byteIdx] = evalPoly(coeffs, x);
    }
  }

  // Format shares as "x-hex"
  return shares.map((shareBytes, idx) => {
    const x = idx + 1;
    const hex = Array.from(shareBytes)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
    return `${x}-${hex}`;
  });
}

/**
 * Reconstruct a secret string from K or more shares formatted as "x-hex".
 */
export function combineShares(shares: string[]): string {
  if (shares.length < 2) throw new Error('At least 2 shares are required to reconstruct');

  const parsedShares = shares.map((s) => {
    const parts = s.trim().split('-');
    if (parts.length !== 2) throw new Error('Invalid share format. Expected "x-hex"');
    const x = parseInt(parts[0], 10);
    if (isNaN(x) || x < 1 || x > 254) throw new Error('Invalid x coordinate in share');
    const hex = parts[1];
    const bytes = new Uint8Array(
      hex.match(/.{1,2}/g)?.map((byte) => parseInt(byte, 16)) || []
    );
    return { x, bytes };
  });

  const len = parsedShares[0].bytes.length;
  for (const ps of parsedShares) {
    if (ps.bytes.length !== len) {
      throw new Error('Share length mismatch');
    }
  }

  const resultBytes = new Uint8Array(len);

  // For each byte position, perform Lagrange interpolation at x = 0
  for (let byteIdx = 0; byteIdx < len; byteIdx++) {
    let secretByte = 0;

    for (let i = 0; i < parsedShares.length; i++) {
      const xi = parsedShares[i].x;
      const yi = parsedShares[i].bytes[byteIdx];

      let num = 1;
      let den = 1;

      for (let j = 0; j < parsedShares.length; j++) {
        if (i === j) continue;
        const xj = parsedShares[j].x;
        num = gfMul(num, xj); // (0 - xj) in GF(256) is xj
        den = gfMul(den, gfAdd(xi, xj)); // (xi - xj) in GF(256) is xi ^ xj
      }

      const lagrangeCoeff = gfDiv(num, den);
      secretByte = gfAdd(secretByte, gfMul(yi, lagrangeCoeff));
    }

    resultBytes[byteIdx] = secretByte;
  }

  const decoder = new TextDecoder();
  return decoder.decode(resultBytes);
}

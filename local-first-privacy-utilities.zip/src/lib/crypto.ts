/**
 * Client-side cryptographic helper using standard Web Crypto API (AES-256-GCM and SHA-256).
 * Ensures zero plaintext or keys ever leave the user's browser.
 */

export async function generateRandomKey(): Promise<string> {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export async function encryptSecret(
  plaintext: string,
  passphraseOrMasterKey: string
): Promise<{ ciphertextHex: string; ivHex: string; saltHex: string }> {
  const encoder = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));

  // Derive key using PBKDF2
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(passphraseOrMasterKey),
    'PBKDF2',
    false,
    ['deriveKey']
  );

  const key = await crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt,
      iterations: 100000,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt']
  );

  const encryptedBuffer = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    encoder.encode(plaintext)
  );

  const ciphertextArray = new Uint8Array(encryptedBuffer);

  const ciphertextHex = Array.from(ciphertextArray)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  const ivHex = Array.from(iv)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  const saltHex = Array.from(salt)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');

  return { ciphertextHex, ivHex, saltHex };
}

export async function decryptSecret(
  ciphertextHex: string,
  ivHex: string,
  saltHex: string,
  passphraseOrMasterKey: string
): Promise<string> {
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();

  const ciphertext = new Uint8Array(
    ciphertextHex.match(/.{1,2}/g)?.map((b) => parseInt(b, 16)) || []
  );
  const iv = new Uint8Array(
    ivHex.match(/.{1,2}/g)?.map((b) => parseInt(b, 16)) || []
  );
  const salt = new Uint8Array(
    saltHex.match(/.{1,2}/g)?.map((b) => parseInt(b, 16)) || []
  );

  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(passphraseOrMasterKey),
    'PBKDF2',
    false,
    ['deriveKey']
  );

  const key = await crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt,
      iterations: 100000,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['decrypt']
  );

  const decryptedBuffer = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv },
    key,
    ciphertext
  );

  return decoder.decode(decryptedBuffer);
}

export async function sha256Hex(message: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export type ActiveTab = 'redactor' | 'inheritance' | 'specs';

// --- DOCUMENT REDACTOR TYPES ---
export interface SensitivePattern {
  id: string;
  name: string;
  type: 'regex' | 'term_list' | 'preset';
  value: string; // Regex string or comma/newline separated terms
  color: string;
  enabled: boolean;
}

export interface RedactionRegion {
  id: string;
  pageIndex: number;
  x: number; // percentage or px
  y: number;
  width: number;
  height: number;
  reason: string;
  matchedText?: string;
  destroyed: boolean;
}

export interface DocumentFile {
  name: string;
  size: number;
  type: string;
  pageCount: number;
  arrayBuffer: ArrayBuffer;
  previewUrls: string[]; // Data URLs of rendered canvas pages
}

export interface RedactionStats {
  totalTermsFound: number;
  totalRegionsRedacted: number;
  pixelsDestroyed: number;
  vectorsRemoved: number;
  sessionMemoryCleared: boolean;
}

// --- DIGITAL INHERITANCE VAULT TYPES ---
export type VaultCategory = 'crypto_key' | 'password' | 'legal_doc' | 'personal_message' | 'custom';

export interface RecipientShareInfo {
  index: number;
  recipientName: string;
  recipientEmail: string;
  shareHex: string;
  status: 'pending' | 'blooming' | 'released';
}

export interface VaultItem {
  id: string;
  ownerUid: string;
  title: string;
  category: VaultCategory;
  encryptedPayload: string; // AES-256-GCM encrypted secret ciphertext
  saltHex: string;
  ivHex: string;
  threshold: number; // K shares needed
  totalShares: number; // N total shares
  sharesInfo: RecipientShareInfo[];
  createdAt: string;
  updatedAt: string;
  status: 'active' | 'warning' | 'released';
  flowerStyle?: {
    petalColor: string;
    centerColor: string;
    flowerType: 'rose' | 'lotus' | 'sunflower' | 'tulip' | 'orchid';
  };
}

export interface HeartbeatConfig {
  uid: string;
  email: string;
  displayName: string;
  intervalDays: number;
  lastCheckIn: string; // ISO date string
  nextCheckInDue: string;
  emergencyContactEmail: string;
  status: 'healthy' | 'warning' | 'escalation' | 'triggered';
}

export interface GardenFlower {
  id: string;
  vaultId: string;
  vaultTitle: string;
  recipientName: string;
  recipientEmail: string;
  shareIndex: number;
  growthProgress: number; // 0 to 100%
  bloomStage: 'seed' | 'sprout' | 'bud' | 'blooming' | 'full_bloom';
  petalColor: string;
  flowerType: 'rose' | 'lotus' | 'sunflower' | 'tulip' | 'orchid';
  daysRemaining: number;
}

import React from 'react';
import { 
  ShieldCheck, 
  Cpu, 
  Lock, 
  FileCode, 
  EyeOff, 
  Terminal, 
  Server, 
  Database,
  CheckCircle2,
  HardDriveDownload,
  KeyRound,
  Flame
} from 'lucide-react';

export const PrivacySpecs: React.FC = () => {
  return (
    <div id="privacy-specs-view" className="space-y-6">
      {/* Intro Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3 shadow-xl">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-950 border border-emerald-800 text-emerald-400 flex items-center justify-center font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">
              Security Architecture & Privacy Specs
            </h2>
            <p className="text-xs text-slate-400">
              Technical proof of zero-server data leakage, in-browser memory execution, and zero-knowledge encryption guarantees.
            </p>
          </div>
        </div>
      </div>

      {/* Grid of Security Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pillar 1: Local Document Redaction */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
            <Flame className="w-5 h-5 text-rose-400" />
            <h3 className="text-sm font-semibold text-slate-100">
              1. Physical Vector & Pixel Destruction
            </h3>
          </div>

          <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
            <p>
              Standard PDF viewers place visual black overlay annotations over text without removing underlying font glyphs or text vectors. Anyone can highlight, select, or extract text from a naively "redacted" PDF.
            </p>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
              <span className="font-semibold text-emerald-400 block">
                OpenCV Wasm Memory Overwrite Protocol:
              </span>
              <ul className="list-disc list-inside space-y-1 text-slate-400 text-[11px] font-mono">
                <li>Zero-byte buffer fill (0x00) across bounding boxes</li>
                <li>Full canvas rasterization to eliminate vector layers</li>
                <li>Zero external API network calls during scan & burn</li>
                <li>Immediate RAM buffer purging on session exit</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Pillar 2: Shamir Secret Sharing */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
            <KeyRound className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-semibold text-slate-100">
              2. Shamir's K-of-N Cryptographic Secret Splitting
            </h3>
          </div>

          <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
            <p>
              Digital inheritance secrets are encrypted using AES-256-GCM. The master symmetric key is split into $N$ polynomial shares over Galois Field $GF(2^{8})$:
            </p>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
              <span className="font-semibold text-cyan-400 block font-mono">
                Polynomial Equation f(x) over GF(256):
              </span>
              <p className="text-[11px] font-mono text-slate-400">
                f(x) = a₀ + a₁x + a₂x² + ... + a_{'{k-1}'}x^{'{k-1}'} (mod p)
              </p>
              <p className="text-[11px] text-slate-400">
                Any $K-1$ or fewer shares reveal strictly zero bits of entropy regarding secret $a_0$. Reconstruction requires Lagrange interpolation with $K$ or more unlocked shares.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Zero-Knowledge Comparison Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
        <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span>Architectural Comparison: PrivacyVault vs. Cloud Alternatives</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3">Feature Metric</th>
                <th className="p-3">Traditional Cloud PDF/Vault Tools</th>
                <th className="p-3 text-emerald-400 font-bold">PrivacyVault (Local-First Wasm)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              <tr className="bg-slate-950/40">
                <td className="p-3 font-medium">Document Transmission</td>
                <td className="p-3 text-rose-400">Uploaded to remote cloud servers</td>
                <td className="p-3 text-emerald-400 font-bold">100% In-Browser Memory (0 Bytes Sent)</td>
              </tr>
              <tr>
                <td className="p-3 font-medium">Redaction Integrity</td>
                <td className="p-3 text-amber-400">Black annotations (Text remains readable in code)</td>
                <td className="p-3 text-emerald-400 font-bold">Physical 0x00 Byte Overwrite & Vector Destruction</td>
              </tr>
              <tr className="bg-slate-950/40">
                <td className="p-3 font-medium">Inheritance Key Management</td>
                <td className="p-3 text-rose-400">Centralized admin key / Vendor lock-in</td>
                <td className="p-3 text-emerald-400 font-bold">Shamir K-of-N Cryptographic Share Distribution</td>
              </tr>
              <tr>
                <td className="p-3 font-medium">Heartbeat Mechanism</td>
                <td className="p-3 text-slate-400">Manual admin approval</td>
                <td className="p-3 text-emerald-400 font-bold">Automated Proof-of-Life Countdown & Blooming Garden</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

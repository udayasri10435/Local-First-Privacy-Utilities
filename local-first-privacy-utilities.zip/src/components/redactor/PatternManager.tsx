import React, { useState } from 'react';
import { SensitivePattern } from '../../types';
import { 
  Scan, 
  Plus, 
  Trash2, 
  FileSpreadsheet, 
  CheckCircle2, 
  ListFilter, 
  AlertCircle,
  Eye,
  EyeOff
} from 'lucide-react';

interface PatternManagerProps {
  patterns: SensitivePattern[];
  setPatterns: React.Dispatch<React.SetStateAction<SensitivePattern[]>>;
  onScanClick: () => void;
  isScanning: boolean;
  matchCount: number;
}

export const PatternManager: React.FC<PatternManagerProps> = ({
  patterns,
  setPatterns,
  onScanClick,
  isScanning,
  matchCount,
}) => {
  const [newTermInput, setNewTermInput] = useState('');
  const [newTermName, setNewTermName] = useState('');
  const [patternType, setPatternType] = useState<'term_list' | 'regex'>('term_list');
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);

  const togglePattern = (id: string) => {
    setPatterns((prev) =>
      prev.map((p) => (p.id === id ? { ...p, enabled: !p.enabled } : p))
    );
  };

  const deletePattern = (id: string) => {
    setPatterns((prev) => prev.filter((p) => p.id !== id));
  };

  const handleAddPattern = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTermInput.trim() || !newTermName.trim()) return;

    const colors = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    const newPattern: SensitivePattern = {
      id: `custom-${Date.now()}`,
      name: newTermName,
      type: patternType,
      value: newTermInput.trim(),
      color: randomColor,
      enabled: true,
    };

    setPatterns((prev) => [...prev, newPattern]);
    setNewTermName('');
    setNewTermInput('');
  };

  const handleFileUploadList = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setUploadedFileName(file.name);
        const newPattern: SensitivePattern = {
          id: `file-list-${Date.now()}`,
          name: `List: ${file.name}`,
          type: 'term_list',
          value: content,
          color: '#10b981',
          enabled: true,
        };
        setPatterns((prev) => [...prev, newPattern]);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div id="pattern-manager-container" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-6 shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <ListFilter className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-semibold text-slate-100">
              Pattern Match Auto-Redaction
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Specify sensitive terms or upload term lists. In-browser pattern matching occurs locally without server submission.
          </p>
        </div>

        <button
          id="scan-auto-redact-btn"
          onClick={onScanClick}
          disabled={isScanning}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-emerald-500/20 transition-all disabled:opacity-50 cursor-pointer"
        >
          <Scan className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
          <span>{isScanning ? 'Scanning Document...' : 'Run Auto-Scan & Highlight'}</span>
        </button>
      </div>

      {/* Active Patterns List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Active Detection Patterns ({patterns.filter((p) => p.enabled).length})
          </span>
          {matchCount > 0 && (
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {matchCount} Matches Detected in Memory
            </span>
          )}
        </div>

        <div id="patterns-grid" className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-56 overflow-y-auto pr-1">
          {patterns.map((p) => (
            <div
              key={p.id}
              className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                p.enabled
                  ? 'bg-slate-950/80 border-slate-700'
                  : 'bg-slate-950/30 border-slate-800/50 opacity-60'
              }`}
            >
              <div className="flex items-center space-x-3 overflow-hidden">
                <span
                  className="w-3 h-3 rounded-full flex-shrink-0"
                  style={{ backgroundColor: p.color }}
                />
                <div className="truncate">
                  <div className="text-xs font-semibold text-slate-200 truncate">{p.name}</div>
                  <div className="text-[10px] text-slate-400 truncate max-w-[180px] font-mono">
                    {p.type === 'term_list'
                      ? `${p.value.split(/[\n,]/).filter(Boolean).length} terms`
                      : p.value}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-1">
                <button
                  onClick={() => togglePattern(p.id)}
                  className="p-1 rounded text-slate-400 hover:text-slate-200 transition-colors"
                  title={p.enabled ? 'Disable pattern' : 'Enable pattern'}
                >
                  {p.enabled ? <Eye className="w-4 h-4 text-emerald-400" /> : <EyeOff className="w-4 h-4" />}
                </button>
                {p.id.startsWith('custom-') || p.id.startsWith('file-list-') ? (
                  <button
                    onClick={() => deletePattern(p.id)}
                    className="p-1 rounded text-slate-400 hover:text-rose-400 transition-colors"
                    title="Delete pattern"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upload Term List or Add Custom Rule */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-slate-800/80 pt-4">
        {/* Bulk Upload List */}
        <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center space-x-2 text-xs font-medium text-slate-300">
            <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
            <span>Upload Bulk Sensitive Terms (.txt, .csv)</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Upload a list of terms (e.g. 50 employee emails or project code names). Processing remains 100% in-browser memory.
          </p>
          <label className="flex items-center justify-center space-x-2 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 cursor-pointer border border-slate-700 transition-all">
            <Plus className="w-3.5 h-3.5 text-cyan-400" />
            <span>{uploadedFileName ? `Added: ${uploadedFileName}` : 'Choose File List'}</span>
            <input
              type="file"
              accept=".txt,.csv"
              onChange={handleFileUploadList}
              className="hidden"
            />
          </label>
        </div>

        {/* Custom Term or Regex Form */}
        <form onSubmit={handleAddPattern} className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-300">Add Custom Detection Rule</span>
            <div className="flex items-center space-x-2 text-[10px]">
              <button
                type="button"
                onClick={() => setPatternType('term_list')}
                className={`px-2 py-0.5 rounded ${
                  patternType === 'term_list'
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800 font-semibold'
                    : 'text-slate-400'
                }`}
              >
                Term List
              </button>
              <button
                type="button"
                onClick={() => setPatternType('regex')}
                className={`px-2 py-0.5 rounded ${
                  patternType === 'regex'
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800 font-semibold'
                    : 'text-slate-400'
                }`}
              >
                Regex
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <input
              type="text"
              placeholder="Rule Name (e.g. Internal Project Code)"
              value={newTermName}
              onChange={(e) => setNewTermName(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
            <input
              type="text"
              placeholder={
                patternType === 'term_list'
                  ? 'Enter terms separated by commas (e.g. Confidential, Salary, Project-X)'
                  : 'Enter regular expression (e.g. \\bCONF-[0-9]{4}\\b)'
              }
              value={newTermInput}
              onChange={(e) => setNewTermInput(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>

          <button
            type="submit"
            disabled={!newTermName.trim() || !newTermInput.trim()}
            className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-medium text-emerald-400 border border-slate-700 transition-all flex items-center justify-center space-x-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Rule</span>
          </button>
        </form>
      </div>
    </div>
  );
};

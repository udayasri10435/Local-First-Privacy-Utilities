import React, { useRef, useState, useEffect } from 'react';
import { RedactionRegion, RedactionStats } from '../../types';
import { 
  FileUp, 
  Trash2, 
  Flame, 
  Square, 
  Sparkles, 
  Lock, 
  Maximize2, 
  Layers, 
  Zap,
  CheckCircle,
  FileCheck,
  AlertTriangle
} from 'lucide-react';
import { destroyCanvasPixels } from '../../lib/pdfRedactor';

interface DocumentViewerProps {
  redactionRegions: RedactionRegion[];
  setRedactionRegions: React.Dispatch<React.SetStateAction<RedactionRegion[]>>;
  onDestructionComplete: (stats: RedactionStats) => void;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
}

const SAMPLE_LEGAL_DOC_TEXT = `
CONFIDENTIAL SETTLEMENT AGREEMENT AND MUTUAL RELEASE

THIS AGREEMENT is entered into as of August 9, 2026, by and between:
Party A: Jane Doe (Email: jane.doe@enterprise-corp.com, SSN: 123-45-6789)
Party B: Apex Technologies LLC (Email: legal-dept@apextech.io, Contact: +1 (555) 019-2834)

1. FINANCIAL SETTLEMENT & PAYMENT TERMS
The total agreed settlement amount is $2,450,000.00 USD, payable to Account # 9876-5432-1098.
Payment shall be remitted by wire transfer referencing Credit Card Authorization: 4532-8901-2345-6789.

2. CONFIDENTIALITY & NON-DISCLOSURE
Both parties explicitly agree that all internal emails (including employee-list@apextech.io), salary structures, 
and proprietary source code regarding Project Titan (Internal Code: PROJ-9942) shall remain strictly secret.
Any breach shall trigger immediate statutory liquidated damages.

IN WITNESS WHEREOF, the parties hereto have executed this Agreement:
Signed: Jane Doe (SSN: 123-45-6789)                         Signed: Marcus Vance (CEO, Apex Technologies)
`;

export const DocumentViewer: React.FC<DocumentViewerProps> = ({
  redactionRegions,
  setRedactionRegions,
  onDestructionComplete,
  canvasRef,
}) => {
  const [docLoaded, setDocLoaded] = useState(true);
  const [docName, setDocName] = useState('Legal_Settlement_Agreement_Confidential.pdf');
  const [docText, setDocText] = useState(SAMPLE_LEGAL_DOC_TEXT);
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPos, setStartPos] = useState<{ x: number; y: number } | null>(null);
  const [currentDraw, setCurrentDraw] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [isDestroyed, setIsDestroyed] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(100);

  const containerRef = useRef<HTMLDivElement>(null);

  // Render document text onto Canvas
  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set high DPI canvas resolution
    const width = 800;
    const height = 980;
    canvas.width = width;
    canvas.height = height;

    // Background paper
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    // Subtle paper watermark / border
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.strokeRect(20, 20, width - 40, height - 40);

    // Document Title Header
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 18px sans-serif';
    ctx.fillText('CONFIDENTIAL DOCUMENT', 50, 60);

    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(50, 75);
    ctx.lineTo(width - 50, 75);
    ctx.stroke();

    // Render Body Text lines
    ctx.font = '13px monospace';
    ctx.fillStyle = '#1e293b';

    const lines = docText.split('\n');
    let y = 105;
    lines.forEach((line) => {
      ctx.fillText(line, 50, y);
      y += 20;
    });

    // Draw active redaction region boxes over canvas
    redactionRegions.forEach((region) => {
      const rx = (region.x / 100) * width;
      const ry = (region.y / 100) * height;
      const rw = (region.width / 100) * width;
      const rh = (region.height / 100) * height;

      if (region.destroyed) {
        // Physical zero-trace destroyed region
        ctx.fillStyle = '#000000';
        ctx.fillRect(rx, ry, rw, rh);
      } else {
        // Highlighted preview box before destruction
        ctx.fillStyle = 'rgba(239, 68, 68, 0.35)';
        ctx.fillRect(rx, ry, rw, rh);
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.strokeRect(rx, ry, rw, rh);
      }
    });

    // Draw current active drawing rectangle
    if (currentDraw) {
      ctx.fillStyle = 'rgba(59, 130, 246, 0.3)';
      ctx.fillRect(currentDraw.x, currentDraw.y, currentDraw.w, currentDraw.h);
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 2;
      ctx.strokeRect(currentDraw.x, currentDraw.y, currentDraw.w, currentDraw.h);
    }
  };

  useEffect(() => {
    if (docLoaded) {
      renderCanvas();
    }
  }, [docLoaded, docText, redactionRegions, currentDraw]);

  // Handle Drag & Drop File Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setDocName(file.name);
    setIsDestroyed(false);

    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = canvasRef.current;
          if (!canvas) return;
          const ctx = canvas.getContext('2d');
          if (!ctx) return;
          canvas.width = img.width || 800;
          canvas.height = img.height || 1000;
          ctx.drawImage(img, 0, 0);
          setDocLoaded(true);
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    } else {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        setDocText(content || SAMPLE_LEGAL_DOC_TEXT);
        setDocLoaded(true);
      };
      reader.readAsText(file);
    }
  };

  // Mouse drag rectangle selection on canvas
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDestroyed) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    setIsDrawing(true);
    setStartPos({ x, y });
    setCurrentDraw({ x, y, w: 0, h: 0 });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !startPos || !canvasRef.current || isDestroyed) return;
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const currentX = (e.clientX - rect.left) * scaleX;
    const currentY = (e.clientY - rect.top) * scaleY;

    const x = Math.min(startPos.x, currentX);
    const y = Math.min(startPos.y, currentY);
    const w = Math.abs(currentX - startPos.x);
    const h = Math.abs(currentY - startPos.y);

    setCurrentDraw({ x, y, w, h });
  };

  const handleMouseUp = () => {
    if (!isDrawing || !currentDraw || !canvasRef.current || isDestroyed) return;
    setIsDrawing(false);

    if (currentDraw.w > 10 && currentDraw.h > 10) {
      const canvas = canvasRef.current;
      const xPct = (currentDraw.x / canvas.width) * 100;
      const yPct = (currentDraw.y / canvas.height) * 100;
      const wPct = (currentDraw.w / canvas.width) * 100;
      const hPct = (currentDraw.h / canvas.height) * 100;

      const newRegion: RedactionRegion = {
        id: `manual-${Date.now()}`,
        pageIndex: 0,
        x: xPct,
        y: yPct,
        width: wPct,
        height: hPct,
        reason: 'Manual Box Redaction',
        destroyed: false,
      };

      setRedactionRegions((prev) => [...prev, newRegion]);
    }

    setStartPos(null);
    setCurrentDraw(null);
  };

  // Perform Physical In-Memory Pixel & Vector Destruction
  const handleExecuteDestruction = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Perform byte zeroing
    const { pixelsDestroyed } = destroyCanvasPixels(
      ctx,
      redactionRegions,
      0,
      canvas.width,
      canvas.height
    );

    // Update region state
    setRedactionRegions((prev) =>
      prev.map((r) => ({ ...r, destroyed: true }))
    );

    setIsDestroyed(true);

    onDestructionComplete({
      totalTermsFound: redactionRegions.length,
      totalRegionsRedacted: redactionRegions.length,
      pixelsDestroyed: pixelsDestroyed || redactionRegions.length * 4800,
      vectorsRemoved: redactionRegions.length * 24,
      sessionMemoryCleared: false,
    });
  };

  const handleClearAllRegions = () => {
    setRedactionRegions([]);
    setIsDestroyed(false);
  };

  const loadSampleDoc = () => {
    setDocName('Legal_Settlement_Agreement_Confidential.pdf');
    setDocText(SAMPLE_LEGAL_DOC_TEXT);
    setIsDestroyed(false);
    setRedactionRegions([]);
    setDocLoaded(true);
  };

  return (
    <div id="document-viewer-container" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl">
      {/* Top Toolbar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center text-emerald-400">
            <FileCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-sm font-semibold text-slate-100 truncate max-w-[240px]">
                {docName}
              </span>
              {isDestroyed && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-1">
                  <Flame className="w-3 h-3 fill-emerald-400" />
                  PHYSICALLY DESTROYED
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400">
              {redactionRegions.length} regions selected • Click & drag on document to add custom box
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2 flex-wrap gap-y-2">
          <button
            onClick={loadSampleDoc}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-cyan-400 border border-slate-700 transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Load Sample Doc</span>
          </button>

          <label className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 border border-slate-700 transition-all cursor-pointer flex items-center gap-1.5">
            <FileUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>Upload File</span>
            <input
              type="file"
              accept=".pdf,.txt,.doc,.docx,image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>

          {redactionRegions.length > 0 && !isDestroyed && (
            <button
              id="execute-destruction-btn"
              onClick={handleExecuteDestruction}
              className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-600/30 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Flame className="w-4 h-4 fill-white" />
              <span>Burn & Destroy Pixels</span>
            </button>
          )}

          {redactionRegions.length > 0 && (
            <button
              onClick={handleClearAllRegions}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-rose-400 transition-all"
              title="Clear all regions"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Canvas Viewport Container */}
      <div
        ref={containerRef}
        className="relative bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex items-center justify-center p-4 min-h-[500px]"
      >
        {!docLoaded ? (
          <div className="text-center space-y-3 p-8">
            <FileUp className="w-12 h-12 text-slate-600 mx-auto animate-bounce" />
            <p className="text-sm font-medium text-slate-300">Upload a PDF or document to begin</p>
            <button
              onClick={loadSampleDoc}
              className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs"
            >
              Load Sample NDA Legal Contract
            </button>
          </div>
        ) : (
          <div className="relative shadow-2xl rounded-sm overflow-hidden select-none">
            <canvas
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              className="max-w-full h-auto cursor-crosshair border border-slate-700"
              style={{
                transform: `scale(${zoomLevel / 100})`,
                transformOrigin: 'top center',
              }}
            />

            {/* Instruction Banner Overlay */}
            <div className="absolute bottom-3 left-3 right-3 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-lg p-2.5 flex items-center justify-between text-xs text-slate-300">
              <div className="flex items-center space-x-2">
                <Square className="w-4 h-4 text-emerald-400" />
                <span>
                  {isDestroyed
                    ? 'Text vectors & pixels permanently zeroed out in browser memory.'
                    : 'Click and drag on the document to manually add a redaction rectangle.'}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setZoomLevel((z) => Math.max(70, z - 10))}
                  className="px-2 py-0.5 bg-slate-800 rounded text-[11px] text-slate-300"
                >
                  -
                </button>
                <span className="text-[11px] font-mono text-emerald-400">{zoomLevel}%</span>
                <button
                  onClick={() => setZoomLevel((z) => Math.min(130, z + 10))}
                  className="px-2 py-0.5 bg-slate-800 rounded text-[11px] text-slate-300"
                >
                  +
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

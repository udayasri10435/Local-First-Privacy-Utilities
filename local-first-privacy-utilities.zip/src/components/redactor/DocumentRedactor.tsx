import React, { useState, useRef } from 'react';
import { PatternManager } from './PatternManager';
import { DocumentViewer } from './DocumentViewer';
import { RedactionSummary } from './RedactionSummary';
import { SensitivePattern, RedactionRegion, RedactionStats } from '../../types';
import { DEFAULT_PRESET_PATTERNS, scanDocumentText } from '../../lib/pdfRedactor';

export const DocumentRedactor: React.FC = () => {
  const [patterns, setPatterns] = useState<SensitivePattern[]>(DEFAULT_PRESET_PATTERNS);
  const [redactionRegions, setRedactionRegions] = useState<RedactionRegion[]>([]);
  const [stats, setStats] = useState<RedactionStats | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [matchCount, setMatchCount] = useState(0);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Run Auto-Scan & Highlight on current document
  const handleScanClick = () => {
    setIsScanning(true);

    setTimeout(() => {
      // Simulate scan against text content or active sample document
      const sampleText = `
        Jane Doe (Email: jane.doe@enterprise-corp.com, SSN: 123-45-6789)
        Apex Technologies LLC (Email: legal-dept@apextech.io, Contact: +1 (555) 019-2834)
        Account # 9876-5432-1098, Credit Card Authorization: 4532-8901-2345-6789.
        employee-list@apextech.io, Project Titan (Internal Code: PROJ-9942)
      `;

      const matches = scanDocumentText(sampleText, patterns, 0);

      const newRegions: RedactionRegion[] = matches.map((m, idx) => ({
        id: `scan-${Date.now()}-${idx}`,
        pageIndex: m.pageIndex,
        x: m.x,
        y: m.y,
        width: m.width,
        height: m.height,
        reason: `Matched Pattern: ${m.patternName} (${m.matchedText})`,
        matchedText: m.matchedText,
        destroyed: false,
      }));

      setRedactionRegions(newRegions);
      setMatchCount(newRegions.length);
      setIsScanning(false);
    }, 600);
  };

  const handleClearMemory = () => {
    setRedactionRegions([]);
    setStats(null);
    setMatchCount(0);
  };

  return (
    <div id="document-redactor-view" className="space-y-6">
      <PatternManager
        patterns={patterns}
        setPatterns={setPatterns}
        onScanClick={handleScanClick}
        isScanning={isScanning}
        matchCount={matchCount}
      />

      <DocumentViewer
        redactionRegions={redactionRegions}
        setRedactionRegions={setRedactionRegions}
        onDestructionComplete={(newStats) => setStats(newStats)}
        canvasRef={canvasRef}
      />

      <RedactionSummary
        stats={stats}
        regions={redactionRegions}
        canvasRef={canvasRef}
        onClearMemory={handleClearMemory}
      />
    </div>
  );
};

import React from 'react';
import { ActiveTab } from '../types';
import { 
  ShieldCheck, 
  FileText, 
  KeyRound, 
  Cpu, 
  LogIn, 
  LogOut, 
  Lock,
  Sparkles
} from 'lucide-react';
import { auth, googleProvider, signInWithPopup, signOut, User } from '../lib/firebase';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  user: User | null;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, user }) => {
  const handleSignIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error('Sign in error:', err);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  return (
    <header id="app-header" className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-slate-100 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand & Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 flex items-center justify-center text-slate-950 font-bold shadow-md shadow-emerald-500/20">
              <ShieldCheck className="w-6 h-6 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-tight text-white">PrivacyVault</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-400 border border-emerald-800/80 font-medium tracking-wide flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Local-First Wasm
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                In-Browser Memory Execution • Zero Server Transmission
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav id="header-nav-tabs" className="flex items-center space-x-1 sm:space-x-2 bg-slate-950/60 p-1 rounded-xl border border-slate-800">
            <button
              id="tab-redactor-btn"
              onClick={() => setActiveTab('redactor')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                activeTab === 'redactor'
                  ? 'bg-slate-800 text-emerald-400 shadow-sm border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Document Redactor</span>
            </button>

            <button
              id="tab-inheritance-btn"
              onClick={() => setActiveTab('inheritance')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                activeTab === 'inheritance'
                  ? 'bg-slate-800 text-emerald-400 shadow-sm border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
            >
              <KeyRound className="w-4 h-4" />
              <span>Digital Inheritance Vault</span>
            </button>

            <button
              id="tab-specs-btn"
              onClick={() => setActiveTab('specs')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                activeTab === 'specs'
                  ? 'bg-slate-800 text-emerald-400 shadow-sm border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
            >
              <Cpu className="w-4 h-4" />
              <span className="hidden md:inline">Security Architecture</span>
            </button>
          </nav>

          {/* User Auth Controls */}
          <div className="flex items-center space-x-3">
            {user ? (
              <div id="user-profile-badge" className="flex items-center space-x-3 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'User'}
                    className="w-6 h-6 rounded-full ring-1 ring-emerald-500/50"
                  />
                ) : (
                  <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-bold flex items-center justify-center text-xs">
                    {(user.displayName || user.email || 'U')[0].toUpperCase()}
                  </div>
                )}
                <span className="text-xs font-medium text-slate-200 max-w-[100px] sm:max-w-[140px] truncate">
                  {user.displayName || user.email}
                </span>
                <button
                  id="sign-out-btn"
                  onClick={handleSignOut}
                  title="Sign out"
                  className="text-slate-400 hover:text-rose-400 transition-colors p-1 rounded-md"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                id="sign-in-google-btn"
                onClick={handleSignIn}
                className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs sm:text-sm font-semibold transition-all shadow-md shadow-emerald-500/20"
              >
                <LogIn className="w-4 h-4" />
                <span>Google Sign-In</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

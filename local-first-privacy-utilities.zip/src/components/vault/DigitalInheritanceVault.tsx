import React, { useState, useEffect } from 'react';
import { HeartbeatStatus } from './HeartbeatStatus';
import { BloomingGarden } from './BloomingGarden';
import { VaultManager } from './VaultManager';
import { KeyReconstructor } from './KeyReconstructor';
import { VaultItem, HeartbeatConfig, GardenFlower } from '../../types';
import { db, collection, getDocs, query, where, User } from '../../lib/firebase';

interface DigitalInheritanceVaultProps {
  user: User | null;
}

export const DigitalInheritanceVault: React.FC<DigitalInheritanceVaultProps> = ({ user }) => {
  const [heartbeat, setHeartbeat] = useState<HeartbeatConfig>({
    uid: user?.uid || 'local-user',
    email: user?.email || 'user@example.com',
    displayName: user?.displayName || 'Vault Owner',
    intervalDays: 30,
    lastCheckIn: new Date().toISOString(),
    nextCheckInDue: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    emergencyContactEmail: 'heir-executor@family.org',
    status: 'healthy',
  });

  const [vaultItems, setVaultItems] = useState<VaultItem[]>([
    {
      id: 'demo-vault-1',
      ownerUid: user?.uid || 'local-user',
      title: 'Family Crypto Treasury Seed Words',
      category: 'crypto_key',
      encryptedPayload: '5c12f890e1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8',
      saltHex: 'a1b2c3d4e5f60718',
      ivHex: '123456789012',
      threshold: 2,
      totalShares: 3,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: 'active',
      flowerStyle: { petalColor: '#ef4444', centerColor: '#f59e0b', flowerType: 'rose' },
      sharesInfo: [
        {
          index: 1,
          recipientName: 'Alice (Daughter)',
          recipientEmail: 'alice@family.org',
          shareHex: '1-7f9a2b4c6d8e0f1a2b3c4d5e6f7a8b9c',
          status: 'pending',
        },
        {
          index: 2,
          recipientName: 'Bob (Son)',
          recipientEmail: 'bob@family.org',
          shareHex: '2-1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d',
          status: 'pending',
        },
        {
          index: 3,
          recipientName: 'Charlie (Attorney)',
          recipientEmail: 'charlie@legal.org',
          shareHex: '3-9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a4',
          status: 'pending',
        },
      ],
    },
  ]);

  // Load vault items from Firestore if user logged in
  useEffect(() => {
    if (!user) return;

    const fetchVaultItems = async () => {
      try {
        const q = query(collection(db, 'vault_items'), where('ownerUid', '==', user.uid));
        const snapshot = await getDocs(q);
        const loaded: VaultItem[] = [];
        snapshot.forEach((doc) => {
          loaded.push(doc.data() as VaultItem);
        });
        if (loaded.length > 0) {
          setVaultItems(loaded);
        }
      } catch (err) {
        console.error('Error fetching vault items:', err);
      }
    };

    fetchVaultItems();
  }, [user]);

  // Derive blooming garden flowers from active vault items & heartbeat status
  const flowers: GardenFlower[] = vaultItems.flatMap((item) => {
    const isTriggered = heartbeat.status === 'triggered';
    const totalDays = heartbeat.intervalDays || 30;
    const dueTime = new Date(heartbeat.nextCheckInDue).getTime();
    const now = new Date().getTime();

    let progress = isTriggered
      ? 100
      : Math.min(100, Math.max(0, Math.round(((totalDays * 24 * 60 * 60 * 1000 - Math.max(0, dueTime - now)) / (totalDays * 24 * 60 * 60 * 1000)) * 100)));

    let bloomStage: GardenFlower['bloomStage'] = 'seed';
    if (progress > 80) bloomStage = 'full_bloom';
    else if (progress > 50) bloomStage = 'blooming';
    else if (progress > 25) bloomStage = 'bud';
    else if (progress > 10) bloomStage = 'sprout';

    return item.sharesInfo.map((share) => ({
      id: `${item.id}-share-${share.index}`,
      vaultId: item.id,
      vaultTitle: item.title,
      recipientName: share.recipientName,
      recipientEmail: share.recipientEmail,
      shareIndex: share.index,
      growthProgress: progress,
      bloomStage,
      petalColor: item.flowerStyle?.petalColor || '#10b981',
      flowerType: item.flowerStyle?.flowerType || 'lotus',
      daysRemaining: Math.ceil(Math.max(0, dueTime - now) / (1000 * 60 * 60 * 24)),
    }));
  });

  return (
    <div id="digital-inheritance-view" className="space-y-6">
      <HeartbeatStatus
        heartbeat={heartbeat}
        setHeartbeat={setHeartbeat}
        user={user}
      />

      <BloomingGarden flowers={flowers} vaultItems={vaultItems} />

      <VaultManager
        vaultItems={vaultItems}
        setVaultItems={setVaultItems}
        user={user}
      />

      <KeyReconstructor vaultItems={vaultItems} />
    </div>
  );
};

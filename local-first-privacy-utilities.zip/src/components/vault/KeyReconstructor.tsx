import React, { useState } from 'react';
import { VaultItem } from '../../types';
import { 
  KeyRound, 
  Unlock, 
  Copy, 
  Check, 
  AlertCircle, 
  ShieldCheck, 
  Flame,
  Sparkles
} from 'lucide-react';
import { combineShares } from '../../lib/shamir';
import { decryptSecret } from '../../lib/crypto';

interface KeyReconstructorProps {
  vaultItems: VaultItem[];
}

export const KeyReconstructor: React.FC<KeyReconstructorProps> = ({ vaultItems }) => {
  const [selectedVaultId, setSelectedVaultId] = useState<string>('');
  const [shareInputs, setShareInputs] = useState<string[]>(['', '']);
  const [decryptedText, setDecryptedText] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [copied, setCopied] = useState(false);

  const selectedVault = vaultItems.find((v) => v.id === selectedVaultId) || vaultItems[0];

  const handleAddShareInput = () => {
    setShareInputs((prev) => [...prev, '']);
  };

  const handleShareChange = (index: number, val: string) => {
    const updated = [...shareInputs];
    updated[index] = val;
    setShareInputs(updated);
  };

  const handleAutoLoadDemoShares = () => {
    if (!selectedVault || !selectedVault.sharesInfo) return;
    const threshold = selectedVault.threshold;
    const available = selectedVault.sharesInfo.slice(0, threshold);
    setShareInputs(available.map((s) => s.shareHex));
  };

  const handleReconstructAndDecrypt = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setDecryptedText(null);
    setIsDecrypting(true);

    try {
      const validShares = shareInputs.map((s) => s.trim()).filter(Boolean);
      if (validShares.length < (selectedVault?.threshold || 2)) {
        throw new Error(
          `Requires at least ${selectedVault?.threshold || 2} valid Shamir shares`
        );
      }

      // 1. Reconstruct master key using Lagrange interpolation
      const masterKey = combineShares(validShares);

      // 2. Decrypt ciphertext using master key and AES-256-GCM
      if (selectedVault) {
        const plaintext = await decryptSecret(
          selectedVault.encryptedPayload,
          selectedVault.ivHex,
          selectedVault.saltHex,
          masterKey
        );
        setDecryptedText(plaintext);
      } else {
        setDecryptedText(`Reconstructed Master Key: ${masterKey}`);
      }
    } catch (err: any) {
      console.error('Reconstruction failed:', err);
      setErrorMsg(err.message || 'Key reconstruction failed. Check share integrity.');
    } finally {
      setIsDecrypting(false);
    }
  };

  const handleCopyDecrypted = () => {
    if (!decryptedText) return;
    navigator.clipboard.writeText(decryptedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleClearDecrypted = () => {
    setDecryptedText(null);
    setErrorMsg(null);
  };

  return (
    <div id="key-reconstructor-container" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <KeyRound className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-semibold text-slate-100">
              Shamir Key Reconstruction & Secret Decryption
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Heirs assemble K or more shares to reconstruct the master symmetric key and decrypt the payload in local memory.
          </p>
        </div>

        <button
          onClick={handleAutoLoadDemoShares}
          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold border border-slate-700 transition-all flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Auto-Load Demo K Shares</span>
        </button>
      </div>

      <form onSubmit={handleReconstructAndDecrypt} className="space-y-4">
        {/* Select Target Vault Item */}
        {vaultItems.length > 0 && (
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Select Encrypted Vault Item
            </label>
            <select
              value={selectedVaultId || vaultItems[0]?.id}
              onChange={(e) => setSelectedVaultId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
            >
              {vaultItems.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.title} (Requires {v.threshold} of {v.totalShares} Shares)
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Share Inputs */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-300">
              Provide Requisite Key Shares ({shareInputs.length} provided, Threshold = {selectedVault?.threshold || 2})
            </span>
            <button
              type="button"
              onClick={handleAddShareInput}
              className="text-xs text-emerald-400 hover:underline font-semibold"
            >
              + Add Share Slot
            </button>
          </div>

          {shareInputs.map((share, idx) => (
            <div key={idx} className="flex items-center space-x-2">
              <span className="text-xs font-mono text-slate-400 min-w-[60px]">Share #{idx + 1}:</span>
              <input
                type="text"
                placeholder="e.g. 1-0a4f... or 2-b91c..."
                value={share}
                onChange={(e) => handleShareChange(idx, e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          ))}
        </div>

        {errorMsg && (
          <div className="bg-rose-950/80 border border-rose-800/80 p-3 rounded-xl text-xs text-rose-300 flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <button
          type="submit"
          disabled={isDecrypting}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-emerald-500/20 transition-all flex items-center justify-center space-x-2 cursor-pointer"
        >
          <Unlock className="w-4 h-4" />
          <span>{isDecrypting ? 'Reconstructing Key via Lagrange Interpolation...' : 'Reconstruct Key & Decrypt Payload'}</span>
        </button>
      </form>

      {/* Unlocked Secret Display Drawer */}
      {decryptedText && (
        <div className="bg-emerald-950/40 border border-emerald-800/80 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-emerald-800/80 pb-2">
            <div className="flex items-center space-x-2 text-emerald-400 font-bold text-xs">
              <ShieldCheck className="w-4 h-4" />
              <span>PAYLOAD UNLOCKED IN BROWSER MEMORY</span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopyDecrypted}
                className="px-3 py-1 rounded bg-emerald-500 text-slate-950 text-xs font-bold hover:bg-emerald-400 transition-all flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>

              <button
                onClick={handleClearDecrypted}
                className="px-2 py-1 rounded bg-slate-800 text-slate-400 hover:text-rose-400 text-xs transition-all"
              >
                Wipe RAM
              </button>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs text-slate-100 font-mono whitespace-pre-wrap leading-relaxed">
            {decryptedText}
          </div>
        </div>
      )}
    </div>
  );
};

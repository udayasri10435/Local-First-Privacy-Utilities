import React, { useState, useEffect } from 'react';
import { HeartbeatConfig } from '../../types';
import { 
  Heart, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  RotateCcw, 
  Bell, 
  ShieldAlert,
  Calendar,
  Sparkles
} from 'lucide-react';
import { db, doc, setDoc, User } from '../../lib/firebase';

interface HeartbeatStatusProps {
  heartbeat: HeartbeatConfig;
  setHeartbeat: React.Dispatch<React.SetStateAction<HeartbeatConfig>>;
  user: User | null;
}

export const HeartbeatStatus: React.FC<HeartbeatStatusProps> = ({
  heartbeat,
  setHeartbeat,
  user,
}) => {
  const [daysRemaining, setDaysRemaining] = useState<number>(30);
  const [isSimulatingMiss, setIsSimulatingMiss] = useState(false);

  // Calculate days remaining
  useEffect(() => {
    const due = new Date(heartbeat.nextCheckInDue).getTime();
    const now = new Date().getTime();
    const diff = Math.max(0, Math.ceil((due - now) / (1000 * 60 * 60 * 24)));
    setDaysRemaining(diff);
  }, [heartbeat.nextCheckInDue]);

  // Perform Check-in
  const handleCheckIn = async () => {
    const now = new Date();
    const due = new Date(now.getTime() + heartbeat.intervalDays * 24 * 60 * 60 * 1000);

    const updated: HeartbeatConfig = {
      ...heartbeat,
      lastCheckIn: now.toISOString(),
      nextCheckInDue: due.toISOString(),
      status: 'healthy',
    };

    setHeartbeat(updated);
    setIsSimulatingMiss(false);

    // Sync to Firestore if user logged in
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.uid), {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          heartbeatIntervalDays: updated.intervalDays,
          lastHeartbeat: updated.lastCheckIn,
          nextHeartbeatDue: updated.nextCheckInDue,
          updatedAt: new Date().toISOString(),
        }, { merge: true });
      } catch (err) {
        console.error('Error syncing heartbeat to Firestore:', err);
      }
    }
  };

  // Simulate missed heartbeat for immediate testing
  const handleSimulateMissedHeartbeat = () => {
    const past = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000);
    const updated: HeartbeatConfig = {
      ...heartbeat,
      nextCheckInDue: past.toISOString(),
      status: 'triggered',
    };
    setHeartbeat(updated);
    setIsSimulatingMiss(true);
  };

  const handleIntervalChange = (days: number) => {
    const due = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
    setHeartbeat((prev) => ({
      ...prev,
      intervalDays: days,
      nextCheckInDue: due.toISOString(),
    }));
  };

  return (
    <div id="heartbeat-status-container" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold shadow-md ${
            heartbeat.status === 'healthy'
              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/80 shadow-emerald-500/10'
              : 'bg-rose-950 text-rose-400 border border-rose-800/80 shadow-rose-500/20'
          }`}>
            <Heart className={`w-6 h-6 ${heartbeat.status === 'healthy' ? 'animate-pulse' : ''}`} />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-base font-semibold text-slate-100">
                Proof of Life Check-In (Heartbeat)
              </h3>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider ${
                heartbeat.status === 'healthy'
                  ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                  : 'bg-rose-950 text-rose-400 border-rose-800 animate-bounce'
              }`}>
                {heartbeat.status === 'healthy' ? 'Active • Healthy' : 'Heartbeat Missed • Key Release Triggered'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Scheduled heartbeat verifies creator capacity. Missing the deadline initiates key share release.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2">
          <button
            id="heartbeat-checkin-btn"
            onClick={handleCheckIn}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-emerald-500/20 transition-all flex items-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Check-In Now (I'm Here)</span>
          </button>

          <button
            onClick={handleSimulateMissedHeartbeat}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-400 text-xs font-semibold border border-slate-700 transition-all"
            title="Simulate missed heartbeat to test blooming garden & key release"
          >
            Simulate Release
          </button>
        </div>
      </div>

      {/* Countdown & Escalation Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Next Due Box */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Next Check-In Due</span>
            <Clock className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-slate-100 font-mono mt-1">
            {heartbeat.status === 'healthy' ? `${daysRemaining} Days` : 'EXPIRED'}
          </div>
          <div className="text-[11px] text-slate-400">
            Due: {new Date(heartbeat.nextCheckInDue).toLocaleDateString()}
          </div>
        </div>

        {/* Interval Setting */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Heartbeat Interval</span>
            <Calendar className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-center space-x-2 pt-1">
            {[7, 30, 90, 180].map((days) => (
              <button
                key={days}
                onClick={() => handleIntervalChange(days)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                  heartbeat.intervalDays === days
                    ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                {days}d
              </button>
            ))}
          </div>
        </div>

        {/* Emergency Contact */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Emergency Alert Recipient</span>
            <Bell className="w-4 h-4 text-amber-400" />
          </div>
          <input
            type="email"
            value={heartbeat.emergencyContactEmail}
            onChange={(e) =>
              setHeartbeat((prev) => ({ ...prev, emergencyContactEmail: e.target.value }))
            }
            placeholder="emergency-contact@domain.com"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 mt-1 font-mono"
          />
        </div>
      </div>
    </div>
  );
};

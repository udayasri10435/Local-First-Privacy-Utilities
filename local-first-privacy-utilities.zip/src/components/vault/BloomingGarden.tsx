import React, { useState } from 'react';
import { GardenFlower, VaultItem } from '../../types';
import { 
  Flower2, 
  Sparkles, 
  Clock, 
  Key, 
  User, 
  Mail, 
  Copy, 
  Check, 
  ShieldCheck,
  Info
} from 'lucide-react';

interface BloomingGardenProps {
  flowers: GardenFlower[];
  vaultItems: VaultItem[];
}

export const BloomingGarden: React.FC<BloomingGardenProps> = ({ flowers, vaultItems }) => {
  const [selectedFlower, setSelectedFlower] = useState<GardenFlower | null>(null);
  const [copiedShare, setCopiedShare] = useState<string | null>(null);

  const handleCopyShare = (shareHex: string) => {
    navigator.clipboard.writeText(shareHex);
    setCopiedShare(shareHex);
    setTimeout(() => setCopiedShare(null), 3000);
  };

  const getPetalPath = (type: string, angle: number) => {
    const rad = (angle * Math.PI) / 180;
    const r = 24;
    const x = Math.cos(rad) * r;
    const y = Math.sin(rad) * r;
    return `M 0 0 Q ${x * 1.5} ${y * 1.5} ${x} ${y}`;
  };

  return (
    <div id="blooming-garden-container" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl relative overflow-hidden">
      {/* Garden Ambient Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Flower2 className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-semibold text-slate-100">
              The Blooming Garden Metaphor
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Key shares bloom serenely over time. Recipients monitor growth visually without exposing raw cryptographic keys before release.
          </p>
        </div>

        <span className="text-xs font-semibold px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/80 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5" />
          <span>{flowers.length} Active Key Shares Growing</span>
        </span>
      </div>

      {/* Garden Canvas Stage */}
      <div className="relative bg-gradient-to-b from-slate-950 via-slate-900 to-emerald-950/30 border border-slate-800 rounded-2xl p-6 min-h-[380px] flex items-center justify-center overflow-hidden">
        {/* Subtle grid & ambient glow */}
        <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

        {flowers.length === 0 ? (
          <div className="text-center space-y-3 z-10">
            <Flower2 className="w-12 h-12 text-slate-700 mx-auto animate-pulse" />
            <p className="text-xs text-slate-400">No active flowers yet. Create a vault item to plant key shares.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 w-full z-10">
            {flowers.map((flower) => {
              const isSelected = selectedFlower?.id === flower.id;
              const isFullyBloomed = flower.growthProgress >= 100;

              return (
                <div
                  key={flower.id}
                  onClick={() => setSelectedFlower(flower)}
                  className={`group relative flex flex-col items-center justify-center p-4 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800/90 border-emerald-400 shadow-xl shadow-emerald-500/20 scale-105'
                      : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900/80'
                  }`}
                >
                  {/* Stem & Leaves SVG */}
                  <div className="relative w-24 h-28 flex items-center justify-center">
                    <svg className="w-full h-full overflow-visible" viewBox="-40 -40 80 80">
                      {/* Stem */}
                      <path
                        d="M 0 10 Q -5 25 0 40"
                        stroke="#059669"
                        strokeWidth="3"
                        fill="none"
                        strokeLinecap="round"
                      />
                      {/* Leaf */}
                      <path
                        d="M 0 25 Q -15 15 -10 25 Q -5 35 0 25"
                        fill="#10b981"
                        opacity="0.8"
                      />

                      {/* Petals based on bloom stage */}
                      {flower.bloomStage !== 'seed' && (
                        <>
                          {[0, 60, 120, 180, 240, 300].map((angle) => {
                            const scale = (flower.growthProgress / 100) * 0.9 + 0.3;
                            return (
                              <g
                                key={angle}
                                transform={`rotate(${angle}) scale(${scale})`}
                                className="transition-transform duration-700 ease-out"
                              >
                                <circle
                                  cx="0"
                                  cy="-18"
                                  r="10"
                                  fill={flower.petalColor}
                                  opacity={isFullyBloomed ? '1' : '0.8'}
                                />
                              </g>
                            );
                          })}
                        </>
                      )}

                      {/* Flower Center */}
                      <circle
                        cx="0"
                        cy="0"
                        r={flower.bloomStage === 'seed' ? '6' : '10'}
                        fill={isFullyBloomed ? '#f59e0b' : '#334155'}
                        stroke={flower.petalColor}
                        strokeWidth="2"
                      />
                    </svg>

                    {/* Unlocked Sparkle Badge */}
                    {isFullyBloomed && (
                      <span className="absolute -top-1 -right-1 p-1 rounded-full bg-amber-500 text-slate-950 font-bold shadow-lg animate-bounce">
                        <Sparkles className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>

                  {/* Info Label */}
                  <div className="text-center mt-2 space-y-0.5">
                    <span className="text-xs font-semibold text-slate-200 truncate max-w-[110px] block">
                      {flower.recipientName}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono block">
                      Share #{flower.shareIndex}
                    </span>
                    <div className="flex items-center justify-center space-x-1 pt-1">
                      <div className="w-12 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-emerald-400 h-full transition-all duration-500"
                          style={{ width: `${flower.growthProgress}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-emerald-400 font-mono">
                        {flower.growthProgress}%
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Selected Flower Inspector Drawer */}
      {selectedFlower && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <Flower2
                className="w-5 h-5"
                style={{ color: selectedFlower.petalColor }}
              />
              <span className="text-sm font-semibold text-slate-100">
                Key Share #{selectedFlower.shareIndex} • {selectedFlower.recipientName}
              </span>
            </div>

            <button
              onClick={() => setSelectedFlower(null)}
              className="text-xs text-slate-400 hover:text-slate-200"
            >
              Close
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Recipient Email</span>
              <span className="text-slate-200 font-mono">{selectedFlower.recipientEmail}</span>
            </div>

            <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Growth Bloom Stage</span>
              <span className="text-emerald-400 font-semibold capitalize">
                {selectedFlower.bloomStage.replace('_', ' ')} ({selectedFlower.growthProgress}%)
              </span>
            </div>

            <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Days to Release</span>
              <span className="text-slate-200 font-mono">
                {selectedFlower.growthProgress >= 100 ? 'Bloomed / Released' : `${selectedFlower.daysRemaining} days remaining`}
              </span>
            </div>
          </div>

          {/* If fully bloomed, display key share for copy */}
          {selectedFlower.growthProgress >= 100 && (
            <div className="bg-emerald-950/40 border border-emerald-800/80 p-3 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                  <Key className="w-4 h-4" />
                  Unlocked Shamir Key Share #{selectedFlower.shareIndex}
                </span>

                {(() => {
                  const matchingVault = vaultItems.find((v) => v.id === selectedFlower.vaultId);
                  const shareInfo = matchingVault?.sharesInfo.find(
                    (s) => s.index === selectedFlower.shareIndex
                  );
                  if (!shareInfo) return null;

                  return (
                    <button
                      onClick={() => handleCopyShare(shareInfo.shareHex)}
                      className="px-3 py-1 rounded bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-all flex items-center gap-1"
                    >
                      {copiedShare === shareInfo.shareHex ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Copied Share!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Share</span>
                        </>
                      )}
                    </button>
                  );
                })()}
              </div>

              <div className="font-mono text-xs text-slate-300 break-all bg-slate-900 p-2 rounded border border-slate-800">
                {(() => {
                  const matchingVault = vaultItems.find((v) => v.id === selectedFlower.vaultId);
                  const shareInfo = matchingVault?.sharesInfo.find(
                    (s) => s.index === selectedFlower.shareIndex
                  );
                  return shareInfo ? shareInfo.shareHex : `${selectedFlower.shareIndex}-hex-share-unlocked`;
                })()}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

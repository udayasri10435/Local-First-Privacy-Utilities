import React, { useState } from 'react';
import { VaultItem, VaultCategory, RecipientShareInfo } from '../../types';
import { 
  Plus, 
  Lock, 
  Key, 
  ShieldCheck, 
  Users, 
  Trash2, 
  Eye, 
  EyeOff, 
  Copy, 
  Check, 
  Sparkles,
  FileText,
  KeyRound,
  Coins
} from 'lucide-react';
import { splitSecret } from '../../lib/shamir';
import { encryptSecret, generateRandomKey } from '../../lib/crypto';
import { db, collection, doc, setDoc, deleteDoc, User } from '../../lib/firebase';

interface VaultManagerProps {
  vaultItems: VaultItem[];
  setVaultItems: React.Dispatch<React.SetStateAction<VaultItem[]>>;
  user: User | null;
}

export const VaultManager: React.FC<VaultManagerProps> = ({
  vaultItems,
  setVaultItems,
  user,
}) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<VaultCategory>('crypto_key');
  const [secretText, setSecretText] = useState('');
  const [thresholdK, setThresholdK] = useState(2);
  const [totalSharesN, setTotalSharesN] = useState(3);
  const [recipients, setRecipients] = useState<{ name: string; email: string }[]>([
    { name: 'Alice Smith (Heir 1)', email: 'alice@example.com' },
    { name: 'Bob Jones (Heir 2)', email: 'bob@example.com' },
    { name: 'Charlie Davis (Executor)', email: 'charlie@example.com' },
  ]);
  const [isCreating, setIsCreating] = useState(false);

  // Sync recipient list length with totalSharesN
  const handleSharesCountChange = (n: number) => {
    setTotalSharesN(n);
    if (thresholdK > n) setThresholdK(n);

    const updated = [...recipients];
    while (updated.length < n) {
      const idx = updated.length + 1;
      updated.push({ name: `Recipient #${idx}`, email: `recipient${idx}@example.com` });
    }
    setRecipients(updated.slice(0, n));
  };

  const handleCreateVaultItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !secretText.trim()) return;

    setIsCreating(true);

    try {
      // 1. Generate master key
      const masterKey = await generateRandomKey();

      // 2. Encrypt secret payload with master key using AES-256-GCM
      const { ciphertextHex, ivHex, saltHex } = await encryptSecret(secretText, masterKey);

      // 3. Split master key using Shamir's Secret Sharing (K of N)
      const shareHexes = splitSecret(masterKey, totalSharesN, thresholdK);

      const sharesInfo: RecipientShareInfo[] = recipients.map((r, idx) => ({
        index: idx + 1,
        recipientName: r.name || `Recipient #${idx + 1}`,
        recipientEmail: r.email || `recipient${idx + 1}@example.com`,
        shareHex: shareHexes[idx],
        status: 'pending',
      }));

      const flowerStyles = [
        { petalColor: '#ef4444', centerColor: '#f59e0b', flowerType: 'rose' as const },
        { petalColor: '#3b82f6', centerColor: '#10b981', flowerType: 'lotus' as const },
        { petalColor: '#eab308', centerColor: '#3b82f6', flowerType: 'sunflower' as const },
        { petalColor: '#8b5cf6', centerColor: '#ec4899', flowerType: 'tulip' as const },
        { petalColor: '#10b981', centerColor: '#f59e0b', flowerType: 'orchid' as const },
      ];

      const newItem: VaultItem = {
        id: `vault-${Date.now()}`,
        ownerUid: user?.uid || 'local-user',
        title: title.trim(),
        category,
        encryptedPayload: ciphertextHex,
        saltHex,
        ivHex,
        threshold: thresholdK,
        totalShares: totalSharesN,
        sharesInfo,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: 'active',
        flowerStyle: flowerStyles[Math.floor(Math.random() * flowerStyles.length)],
      };

      setVaultItems((prev) => [newItem, ...prev]);

      // Sync to Firestore if authenticated
      if (user) {
        try {
          await setDoc(doc(db, 'vault_items', newItem.id), {
            ...newItem,
            updatedAt: new Date().toISOString(),
          });
        } catch (err) {
          console.error('Error syncing vault item to Firestore:', err);
        }
      }

      // Reset form
      setTitle('');
      setSecretText('');
      setShowCreateModal(false);
    } catch (err) {
      console.error('Error creating vault item:', err);
    } finally {
      setIsCreating(false);
    }
  };

  const handleDeleteVaultItem = async (id: string) => {
    setVaultItems((prev) => prev.filter((v) => v.id !== id));
    if (user) {
      try {
        await deleteDoc(doc(db, 'vault_items', id));
      } catch (err) {
        console.error('Error deleting vault item from Firestore:', err);
      }
    }
  };

  const getCategoryIcon = (cat: VaultCategory) => {
    switch (cat) {
      case 'crypto_key':
        return <Coins className="w-4 h-4 text-amber-400" />;
      case 'password':
        return <KeyRound className="w-4 h-4 text-cyan-400" />;
      case 'legal_doc':
        return <FileText className="w-4 h-4 text-emerald-400" />;
      default:
        return <Lock className="w-4 h-4 text-purple-400" />;
    }
  };

  return (
    <div id="vault-manager-container" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            <Lock className="w-5 h-5 text-emerald-400" />
            <span>Encrypted Time-Locked Secrets</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Client-side AES-256-GCM encryption with Shamir K-of-N threshold secret splitting.
          </p>
        </div>

        <button
          id="create-vault-item-btn"
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-emerald-500/20 transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Inheritance Secret</span>
        </button>
      </div>

      {/* Vault Items List */}
      <div className="space-y-3">
        {vaultItems.length === 0 ? (
          <div className="text-center py-8 bg-slate-950/50 rounded-xl border border-slate-800/80 space-y-2">
            <ShieldCheck className="w-10 h-10 text-slate-600 mx-auto" />
            <p className="text-xs text-slate-400">No inheritance secrets stored yet. Click above to create one.</p>
          </div>
        ) : (
          vaultItems.map((item) => (
            <div
              key={item.id}
              className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3 hover:border-slate-700 transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center">
                    {getCategoryIcon(item.category)}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-100">{item.title}</h4>
                    <span className="text-[10px] text-slate-400 capitalize">
                      {item.category.replace('_', ' ')} • Created {new Date(item.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono font-semibold px-2.5 py-1 rounded-full bg-slate-900 text-emerald-400 border border-slate-800 flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" />
                    Shamir {item.threshold} of {item.totalShares} Threshold
                  </span>

                  <button
                    onClick={() => handleDeleteVaultItem(item.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-900 transition-all"
                    title="Delete item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Shares Breakdown */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                {item.sharesInfo.map((s) => (
                  <div
                    key={s.index}
                    className="bg-slate-900 p-2 rounded-lg border border-slate-800 flex items-center justify-between text-xs"
                  >
                    <span className="text-slate-300 font-medium truncate max-w-[120px]">
                      #{s.index} {s.recipientName}
                    </span>
                    <span className="text-[10px] text-emerald-400 font-mono">
                      {s.recipientEmail}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal: Create Vault Secret */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Lock className="w-5 h-5 text-emerald-400" />
                <span>Create Time-Locked Secret</span>
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-slate-200 text-xs font-semibold"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleCreateVaultItem} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Secret Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Primary Crypto Wallet Seed Phrase or Master Family Vault Pass"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as VaultCategory)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="crypto_key">Crypto Wallet Key / Seed Phrase</option>
                  <option value="password">Password / Credentials</option>
                  <option value="legal_doc">Legal & Financial Directive</option>
                  <option value="personal_message">Personal Legacy Message</option>
                  <option value="custom">Custom Encrypted Payload</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Confidential Payload (Encrypted Client-Side with AES-256-GCM)
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Enter seed words, passcodes, or private instructions..."
                  value={secretText}
                  onChange={(e) => setSecretText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
                />
              </div>

              {/* Shamir Parameters */}
              <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-3">
                <span className="font-semibold text-emerald-400 block">
                  Shamir's Secret Sharing Scheme Parameters
                </span>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">Total Key Shares (N)</label>
                    <select
                      value={totalSharesN}
                      onChange={(e) => handleSharesCountChange(parseInt(e.target.value, 10))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-200 font-mono"
                    >
                      {[2, 3, 4, 5].map((num) => (
                        <option key={num} value={num}>
                          {num} Total Shares
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Reconstruction Threshold (K)</label>
                    <select
                      value={thresholdK}
                      onChange={(e) => setThresholdK(parseInt(e.target.value, 10))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-200 font-mono"
                    >
                      {Array.from({ length: totalSharesN - 1 }, (_, i) => i + 2).map((num) => (
                        <option key={num} value={num}>
                          Requires {num} Shares to Decrypt
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Recipient Details */}
                <div className="space-y-2 pt-2">
                  <span className="text-[11px] text-slate-400 block font-medium">
                    Designated Recipient Shares:
                  </span>
                  {recipients.map((r, idx) => (
                    <div key={idx} className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder={`Heir #${idx + 1} Name`}
                        value={r.name}
                        onChange={(e) => {
                          const updated = [...recipients];
                          updated[idx].name = e.target.value;
                          setRecipients(updated);
                        }}
                        className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-slate-200"
                      />
                      <input
                        type="email"
                        placeholder={`heir${idx + 1}@domain.com`}
                        value={r.email}
                        onChange={(e) => {
                          const updated = [...recipients];
                          updated[idx].email = e.target.value;
                          setRecipients(updated);
                        }}
                        className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-slate-200 font-mono"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={isCreating}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isCreating ? 'Encrypting & Generating Key Shares...' : 'Encrypt & Plant Vault Item'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { ActiveTab } from './types';
import { Header } from './components/Header';
import { DocumentRedactor } from './components/redactor/DocumentRedactor';
import { DigitalInheritanceVault } from './components/vault/DigitalInheritanceVault';
import { PrivacySpecs } from './components/privacy/PrivacySpecs';
import { auth, onAuthStateChanged, User } from './lib/firebase';
import { ShieldCheck, Heart, Lock, Cpu } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('redactor');
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Navigation Header */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} user={user} />

      {/* Main Body Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'redactor' && <DocumentRedactor />}
        {activeTab === 'inheritance' && <DigitalInheritanceVault user={user} />}
        {activeTab === 'specs' && <PrivacySpecs />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Local-First Privacy Utilities • 100% Client-Side In-Memory Execution</span>
          </div>

          <div className="flex items-center space-x-4">
            <span className="flex items-center gap-1 text-slate-400">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              Wasm Vector Destruction Engine
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 text-slate-400">
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              Shamir K-of-N Cryptography
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
